import  csv
import os
import argparse
#txt_file = r"ItemSets.txt"
#txt_file2 = r"Test.txt"
txt_file3 = r"Yasuo.txt"
txt_file4 = r"Ashe.txt"
#csv_file = r"Transaction.csv"
csv_file2 = r"DataSet.csv"
def head():
    options = parse_options()
    txt_file = options.ItemSet
    txt_file2 = options.Transaction
    with open(txt_file,"r") as in_file,open(txt_file3,"w+") as out_file,open(txt_file2,"r") as in_file2,open(txt_file4,"w+") as output2:
        lines = in_file.read().splitlines()
        count  = lines[0].count(",")
        out_file.writelines(lines)
        output2.writelines(lines)
        transacs = in_file2.read().splitlines()
        out_file.write("\n")
        output2.write("\n")
        for transac in transacs:
            x = 0
            while x<count+1:
                if transac.__contains__(lines[0].split(",")[x]):
                    out_file.write("Y,")
                    output2.write(lines[0].split(",")[x]+",")
                else:
                    out_file.write("?,")
                    output2.write(",")
                x += 1
            out_file.write("\n")
            output2.write("\n")
def final_edit():
    head()
    options = parse_options()
    csv_file = options.DataSetYN
    with open(txt_file3,"r") as input1,open(txt_file4,"r")as input2,open(csv_file,"w+") as output1,open(csv_file2,"w+") as output2:
        lines = input1.read().splitlines()
        lines[0] += ","
        line2s = input2.read().splitlines()
        line2s[0] += ","
        for line in lines:
            line = line[:-1]
            output1.write(line+"\n")
        for line2 in line2s:
            line2 = line2[:-1]
            output2.write(line2+"\n")
def parse_options():
    optparser = argparse.ArgumentParser(description='Convert')
    optparser.add_argument(
        '-f',
        '--ItemSet',
        dest = 'ItemSet',
        help='txt',
        required=True
    )
    optparser.add_argument(
        '-m','--Transaction',
        dest='Transaction',
        help='txt',
        required=True
    )
    optparser.add_argument(
        '-n','--output_file2',
        dest='DataSetYN',
        help='DataSet.csv',
        required=True
    )
    return optparser.parse_args()

if __name__ == '__main__':
    final_edit()
    print "run successfully"
    os.remove(txt_file3)
    os.remove(txt_file4)